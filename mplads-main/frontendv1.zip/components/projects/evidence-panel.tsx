import { ImageOff } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import type { WorkRecord } from "@/lib/types";

/**
 * Renders evidence only when the API provides a URL. Never fabricates images.
 * `has_evidence_image` alone indicates a record exists, not that it is retrievable here.
 */
export function EvidencePanel({ work }: { work: WorkRecord }) {
  const url = work.evidence_image_url;

  return (
    <Card className="gap-3 rounded-md shadow-none">
      <CardHeader className="pb-0">
        <CardTitle className="text-sm font-semibold">Evidence</CardTitle>
      </CardHeader>
      <CardContent>
        {url ? (
          <figure className="flex flex-col gap-2">
            <img
              src={url}
              alt={`Evidence image on record for work ${work.work_id}`}
              className="aspect-video w-full rounded-md border object-cover"
            />
            <figcaption className="text-[11px] text-muted-foreground">Retrieved from the risk intelligence service.</figcaption>
          </figure>
        ) : (
          <div className="flex flex-col items-center gap-2 rounded-md border border-dashed px-4 py-8 text-center">
            <ImageOff className="size-5 text-muted-foreground" aria-hidden="true" />
            <p className="text-sm font-medium">Evidence data not available</p>
            <p className="text-xs text-muted-foreground text-pretty">
              {work.has_evidence_image
                ? "An evidence image is recorded for this work but is not retrievable through this service."
                : "Additional official records may be required for verification."}
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
