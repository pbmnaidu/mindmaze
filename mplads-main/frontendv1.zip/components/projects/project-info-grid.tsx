import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { SectionHeading } from "@/components/shared/section-heading";
import { RiskBadge } from "@/components/risk/risk-badge";
import { StatusBadge, deriveStatus } from "./status-badge";
import { EvidencePanel } from "./evidence-panel";
import type { WorkRecord } from "@/lib/types";
import { formatDate, formatInr, formatPercent, formatRatio, formatScore, textOrDash, toTitleCase } from "@/lib/utils/format";

interface Field {
  label: string;
  value: React.ReactNode;
}

function InfoCard({ title, fields }: { title: string; fields: Field[] }) {
  return (
    <Card className="gap-3 rounded-md shadow-none">
      <CardHeader className="pb-0">
        <CardTitle className="text-sm font-semibold">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <dl className="divide-y text-xs">
          {fields.map((f) => (
            <div key={f.label} className="flex items-start justify-between gap-4 py-2 first:pt-0 last:pb-0">
              <dt className="shrink-0 text-muted-foreground">{f.label}</dt>
              <dd className="min-w-0 text-right font-medium text-foreground break-words">{f.value}</dd>
            </div>
          ))}
        </dl>
      </CardContent>
    </Card>
  );
}

export function ProjectInfoGrid({ work }: { work: WorkRecord }) {
  const expenditureShare =
    work.sanction_amount > 0 ? work.effective_expenditure / work.sanction_amount : undefined;

  return (
    <section className="flex flex-col gap-3" aria-labelledby="info-heading">
      <SectionHeading title="Project information" description="Source data as recorded in the MPLADS dataset for this work." />
      <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
        <InfoCard
          title="Basic information"
          fields={[
            { label: "Work ID", value: <span className="font-mono">{work.work_id}</span> },
            { label: "Category", value: textOrDash(work.work_category) },
            { label: "State", value: toTitleCase(work.State ?? work.state) },
            { label: "Constituency", value: toTitleCase(work.Constituency ?? work.constituency) },
            { label: "Member of Parliament", value: textOrDash(work.mp_name) },
            { label: "Status", value: <StatusBadge status={deriveStatus(work)} /> },
          ]}
        />
        <InfoCard
          title="Financial information"
          fields={[
            { label: "Sanction amount", value: <span className="font-mono tabular">{formatInr(work.sanction_amount)}</span> },
            { label: "Effective expenditure", value: <span className="font-mono tabular">{formatInr(work.effective_expenditure)}</span> },
            { label: "Expenditure / sanction", value: <span className="font-mono tabular">{formatPercent(expenditureShare)}</span> },
            { label: "Peer category median", value: <span className="font-mono tabular">{formatInr(work.peer_category_median_amount)}</span> },
            { label: "Amount to peer ratio", value: <span className="font-mono tabular">{formatRatio(work.amount_to_peer_ratio)}</span> },
            { label: "Category percentile", value: <span className="font-mono tabular">{work.category_percentile !== undefined ? `${formatScore(work.category_percentile)}th` : "—"}</span> },
          ]}
        />
        <InfoCard
          title="Implementation information"
          fields={[
            { label: "Recommended date", value: formatDate(work.recommended_date) },
            { label: "Sanction date", value: formatDate(work.sanction_date) },
            { label: "Completion date", value: formatDate(work.completion_date) },
            { label: "Description", value: <span className="block max-w-56 text-pretty">{textOrDash(work.description)}</span> },
          ]}
        />
        <InfoCard
          title="Vendor & payment information"
          fields={[
            { label: "Top vendor", value: textOrDash(work.top_vendor) },
            { label: "Top vendor share", value: <span className="font-mono tabular">{formatPercent(work.top_vendor_share)}</span> },
            { label: "Vendor risk score", value: <span className="font-mono tabular">{formatScore(work.vendor_risk_score)}</span> },
            { label: "Vendor risk level", value: <RiskBadge level={work.vendor_risk_level} /> },
          ]}
        />
        <InfoCard
          title="Compliance indicators"
          fields={[
            { label: "Compliance risk score", value: <span className="font-mono tabular">{formatScore(work.compliance_risk_score)}</span> },
            { label: "Compliance risk level", value: <RiskBadge level={work.compliance_risk_level} /> },
            { label: "Evidence image on record", value: work.has_evidence_image === undefined ? "—" : work.has_evidence_image ? "Yes" : "No" },
            { label: "Compliance warning", value: <span className="block max-w-56 text-pretty">{textOrDash(work.compliance_explanation)}</span> },
          ]}
        />
        <EvidencePanel work={work} />
      </div>
    </section>
  );
}
